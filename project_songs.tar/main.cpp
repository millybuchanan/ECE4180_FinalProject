#include "mbed.h"       // this tells us to load mbed  related functions
#include "tones.h"      // list of all the tones and their frequencies
#include "SongPlayer.h"

//PwmOut buzzer(D3);                   // our buzzer is a PWM output (pulse-width modulation)

/*static int BPM = 80;

static void silence() {
    buzzer.write(0.0f); // silence!
}

// this is our function that plays a tone. 
// Takes in a tone frequency, and after duration (in ms.) we stop playing again
static void play_tone(int tone) {
    buzzer.period_us(1000000/(tone));
    buzzer.write(0.10f); // 10% duty cycle, otherwise it's too loud
}

static void play_song(int notes_left, int* melody, int* duration) {
    
    // YOUR CODE HERE
 // melody and duration are pointers, they point to the array of tones and durations we declared earlier
    // every time we play a note we up these pointers (move one element forward)
    // so the current tone is always the first element of melody (same for duration)
 
    int length;
 
    while(notes_left > 0)
    {
 
        int tone = melody[0];
        // BPM is quarter notes per minute, so length in milliseconds is:
        length = static_cast<int>(static_cast<float>(1000 / duration[0]) * (60000.0f / static_cast<float>(BPM * 1000)));
 
        play_tone(tone);
 
        // after half the length of this tone, we silence
        wait_ms(length / 2);  
        silence();
 
        //after the full length of this tone, call next note 
        wait_ms(length); 
                   
        // after the full length of this tone, we up the melody, and down the notes_left
        
        notes_left--;
        melody++;
        duration++;
            
    }  
 
    // we're done! just finish this note and silence
    wait_ms(length / 2);  
    silence();   
}*/
    SongPlayer mySpeaker(p26);

    float C = 523;
    float D = 587;
    float E = 659;
    float G = 784;
    float pause = 0;
    
    /*float note[] = {
        NOTE_C4, NOTE_D4, NOTE_DS4, NOTE_C4, NOTE_FS4, NOTE_G4, NOTE_FS4, NOTE_G4, 
        NOTE_FS4, NOTE_G4, NOTE_FS4, NOTE_G4, NOTE_FS4, NOTE_G4, NOTE_FS4, NOTE_G4, 
        NOTE_FS4, NOTE_G4, NOTE_FS4, NOTE_G4    
    };*/

    float note[] = { E, D, C, D, E, E, E, pause, D, D, D, pause, E, G, G, pause, E, D, C, D, E, E, E, E, D, D, E, D, C};

    float duration[] = {0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5};

    /*float duration[] = {
        1, 2, 1, 2, 1, 2, 1, 2, 
        1, 2, 1, 2, 1, 2, 1, 
        2, 1, 2, 1, 2 
    };*/

// this code runs when the microcontroller starts up
int main() {

    // declare a melody
// Start song and return once playing starts
    mySpeaker.PlaySong(note,duration);
    
    return 0;
}
