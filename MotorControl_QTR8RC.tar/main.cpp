#include "mbed.h"
//#include "mbed2/299/TARGET_LPC1768/TARGET_NXP/TARGET_LPC176X/TARGET_MBED_LPC1768/PinNames.h"
#include "Motor.h"

Serial pc(USBTX, USBRX);

DigitalIn sensor[] = {(p13),(p14),(p15),(p16),(p17),(p18),(p19),(p20)};
unsigned int background = 0;
unsigned int line = 1;

Motor mR(p23, p6, p5); // pwm, fwd, rev
Motor mL(p24, p26, p25); // pwm, fwd, rev

void goStraight()
{
    mR.speed(0.2f); 
    mL.speed(0.2f);
    wait(0.2);
    //return;
}

void turnRight()
{
    while(1){
        mR.speed(-0.2f); 
        mL.speed(0.2f);
        wait(0.1);
        mR.speed(0.0f); 
        mL.speed(0.0f);
        wait(0.1);
        if (sensor[0]==line && sensor[1]==line)
        break;
    }
    //return;
}

void turnLeft(){
    while(1){
        mR.speed(0.1f); 
        mL.speed(-0.1f);
        wait(0.1);
        mR.speed(0.0f); 
        mL.speed(0.0f);
        wait(0.1);
        if (sensor[6]==line && sensor[7]==line)
        break;
    }
    //return;
}

int main() {
    for (int i = 0; i < 8; i++)
    {
        sensor[i].mode(PullUp);
    }

    //play start sequence song

    //read sensor values
   /* sensor[0].read();
    sensor[1].read();
    sensor[2].read();
    sensor[3].read();
    sensor[4].read();
    sensor[5].read();
    sensor[6].read();
    sensor[7].read();
    */
    while(1)
    {
    //go straight if edge sensors are on background
        //if(sensor[0]==background && sensor[1]==background && sensor[6]==background && sensor[7]==background)
        if(sensor[2].read()==line || sensor[3].read()==line ||sensor[4].read()==line || sensor[5].read()==line)
        {
            goStraight();
        }
        
        //mL.speed(0.0f);
        //mR.speed(0.0f);
        //wait(1);
    //turn right if right edge sensors see line    
        if(sensor[0].read()==line || sensor[1].read()==line)
            turnRight();
    //turn left if left edge sensors see line
        if(sensor[6].read()==line || sensor[7].read()==line)
            turnLeft();   
    }
}


