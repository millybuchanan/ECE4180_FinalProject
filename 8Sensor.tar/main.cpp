#include "mbed.h"
#include "Motor.h"
#include <PinDetect.h>

Serial pc(USBTX, USBRX);

DigitalIn sensor0(p13);
DigitalIn sensor1(p14);
DigitalIn sensor2(p15);
DigitalIn sensor3(p16);
DigitalIn sensor4(p17);
DigitalIn sensor5(p18);
DigitalIn sensor6(p19);
DigitalIn sensor7(p20);

BusOut leds(LED1, LED2, LED3, LED4);

#define LINE 1
#define BKGD 0

Motor mR(p23, p6, p5); // pwm, fwd, rev
Motor mL(p24, p26, p25); // pwm, fwd, rev

void goStraight()
{
    mR.speed(0.2f); 
    mL.speed(0.2f);
    wait(0.2);
}

void turnRight()
{
    // re-add while (1) with if break statement
    pc.printf("Turning Right\n\n");
    mR.speed(-0.2f); 
    mL.speed(0.2f);
    wait(0.1);
}

void turnLeft()
{
    // re-add while (1) here with if break statement
    pc.printf("Turning Left\n\n");
    mR.speed(0.2f); 
    mL.speed(-0.2f);
    wait(0.1);
}

void exitSequence()
{
    while (1)
    {
        pc.printf("exited");
        for (int i = 0; i < 16; i++)
        {
            leds = i;
        }
    }
}

int main() {
    sensor0.mode(PullUp);
    sensor1.mode(PullUp);
    sensor2.mode(PullUp);
    sensor3.mode(PullUp);
    sensor4.mode(PullUp);
    sensor5.mode(PullUp);
    sensor6.mode(PullUp);
    sensor7.mode(PullUp);

    while(1)
    {
    //go straight if edge sensors are on background
        while (sensor2.read() == LINE || sensor3.read() == LINE ||sensor4.read() == LINE || sensor5.read() == LINE)
        {
            // maybe try this as a while loop?
            if (sensor0.read() == LINE && sensor1.read() == LINE)
            {
                mL.speed(0.0f);
                mR.speed(0.0f);
                turnRight();
            }

            // and this a while loop? 
            if (sensor6.read() == LINE && sensor7.read() == LINE)
            {
                mL.speed(0.0f);
                mR.speed(0.0f);
                turnLeft();
            }
            goStraight();
            pc.printf("Straight\n\n");
            wait(0.1);
        }
        

        pc.printf("Stopping\n\n\n");
        mL.speed(0.0f);
        mR.speed(0.0f);
        break;
    }

    exitSequence();
}


